/* Copyright (c) 2013 Dario Oliveri

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE. */

#pragma once
#include <iostream>

namespace Infector{

    template <typename T>
    void Container::bindSingleAsNothing(){
        bool tests = reduced_type_tests<T>();
        (void) tests; //fix unused variable warning
        must_not_have<T>();

        typeMap[std::type_index(typeid(T))]
                = Binding(std::type_index(typeid(T)), true);

        try{
            if(singleIstances.find( std::type_index(typeid(T)) )
                                    ==singleIstances.end())
                singleIstances[std::type_index(typeid(T))]
                                = new AnyShared<T>();
        }catch(std::exception & ex){
            auto it2 = typeMap.find( std::type_index(typeid(T)) );
            typeMap.erase(it2);
            throw ex;
        }catch(...){
            auto it2 = typeMap.find( std::type_index(typeid(T)) );
            typeMap.erase(it2);
            launch_exception<ExUnkownException>();
        }
    }

    template <typename T, typename... Contracts>
    void Container::bindSingleAs(){
        bool tests = type_tests<T,Contracts...>(); // Compile time tests.
        (void) tests;  //fix unused variable warning

        bool success = false;
        try{
            success = resolve_multiple_inheritance<T,Contracts...>();
        }catch(std::exception & ex){
            rollback_multiple_inheritance<T,Contracts...>(); //revert changes
            throw ex;
        }catch(...){
            rollback_multiple_inheritance<T,Contracts...>(); //revert changes
            launch_exception<ExUnkownException>();
        }


        if(!success) //no changes.
            launch_exception<ExExistingInterface>();

        try{
            if(singleIstances.find( std::type_index(typeid(T)) )
                                    ==singleIstances.end())
                singleIstances[std::type_index(typeid(T))]
                               = new AnyShared<T,Contracts...>();
        }catch(std::exception & ex){
            rollback_multiple_inheritance<T,Contracts...>(); //revert changes
            throw ex;
        }catch(...){
            rollback_multiple_inheritance<T,Contracts...>(); //revert changes
            launch_exception<ExUnkownException>();
        }
    }

    template <typename T>
    std::shared_ptr<T> Container::buildSingle_delegate(){
        auto it = typeMap.find( std::type_index(typeid(T)) );
        if( it==typeMap.end()) //"it" is concrete type, T abstract one
            launch_exception<ExBuildWhat>(); // TYPE NOT REGISTERED

        if( it->second.single == false)
            launch_exception<ExSingleMulti>(); // T must be single

        //at this point may happen that concrete type and abstract ones are the
        //same.that's ok. (bindSingleAsNothing)
        auto it2 = callbacks.find(  it->second.type ); //find constructor

        if( it2==callbacks.end())
            launch_exception<ExNotWired>(); // CONSTRUCTOR NOT WIRED

        auto it3 = singleIstances.find( it->second.type );

        IAnyShared * any = it3->second;
        T* myPointer = reinterpret_cast<T*>(
                                    any->getPtr(std::type_index(typeid(T)))
                                            );
        if(myPointer==nullptr){
            try{
                any->setPtr( (it2->second)(nullptr) );
                myPointer =  reinterpret_cast<T*>(
                                    any->getPtr(std::type_index(typeid(T)))
                                            );

            }catch(std::exception & ex){
                throw ex;
            }catch(...){
                launch_exception<ExUnkownException>();
            }
        }

        if(myPointer == nullptr)
                launch_exception<ExAnySharedNullPtr>();

        return std::move(std::shared_ptr<T> (
                                any->getReferenceCounter(),
                                myPointer ));
    }

    template <typename T>
    std::shared_ptr<T> Container::buildSingle(){
        return std::move(buildSingle_delegate<T>());
    }

} // namespace Infector
